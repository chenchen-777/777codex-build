#!/bin/zsh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="$HOME/Applications"
PATCHER="$ROOT/tools/enable_codex_i18n.py"

echo ""
echo "== ChatGPT / Codex Chinese UI installer for macOS =="
echo ""

if [[ -d "/Applications/ChatGPT.app" ]]; then
  SOURCE_APP="/Applications/ChatGPT.app"
  PRODUCT_NAME="ChatGPT"
  DISPLAY_NAME="ChatGPT Zh"
elif [[ -d "/Applications/Codex.app" ]]; then
  SOURCE_APP="/Applications/Codex.app"
  PRODUCT_NAME="Codex"
  DISPLAY_NAME="Codex Zh"
else
  echo "ERROR: The official ChatGPT desktop app was not found."
  echo "Install the official ChatGPT desktop app first, then run this installer again."
  read "?Press Enter to close"
  exit 1
fi

TARGET_APP="$TARGET_DIR/$DISPLAY_NAME.app"
STAGING_APP="$TARGET_DIR/.$DISPLAY_NAME.app.installing"
ASAR="$STAGING_APP/Contents/Resources/app.asar"
INFO_PLIST="$STAGING_APP/Contents/Info.plist"

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 was not found."
  echo "Install Xcode Command Line Tools or Python 3 first."
  read "?Press Enter to close"
  exit 1
fi

if ! command -v codesign >/dev/null 2>&1; then
  echo "ERROR: codesign was not found."
  echo "Install Xcode Command Line Tools first."
  read "?Press Enter to close"
  exit 1
fi

SOURCE_VERSION="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$SOURCE_APP/Contents/Info.plist" 2>/dev/null || echo unknown)"
SOURCE_EXECUTABLE="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$SOURCE_APP/Contents/Info.plist" 2>/dev/null || true)"

if [[ -z "$SOURCE_EXECUTABLE" || ! -x "$SOURCE_APP/Contents/MacOS/$SOURCE_EXECUTABLE" ]]; then
  echo "ERROR: The main executable was not found in $SOURCE_APP"
  read "?Press Enter to close"
  exit 1
fi

echo "Official app: $SOURCE_APP"
echo "Version: $SOURCE_VERSION"
echo "Chinese copy: $TARGET_APP"
echo ""
echo "Closing ChatGPT/Codex before copying..."
osascript -e 'tell application "ChatGPT" to quit' >/dev/null 2>&1 || true
osascript -e 'tell application "Codex" to quit' >/dev/null 2>&1 || true
pkill -x "ChatGPT" >/dev/null 2>&1 || true
pkill -x "Codex" >/dev/null 2>&1 || true
sleep 1

echo "Copying the official app to a temporary user folder..."
mkdir -p "$TARGET_DIR"
rm -rf "$STAGING_APP"
ditto "$SOURCE_APP" "$STAGING_APP"

if [[ ! -f "$ASAR" ]]; then
  echo "ERROR: app.asar was not found in the copied app."
  rm -rf "$STAGING_APP"
  read "?Press Enter to close"
  exit 1
fi

echo "Enabling Chinese UI and updating ASAR integrity..."
python3 "$PATCHER" "$ASAR" \
  --info-plist "$INFO_PLIST" \
  --display-name "$DISPLAY_NAME"
rm -f "$ASAR.bak-before-i18n"

echo "Removing quarantine attribute..."
xattr -dr com.apple.quarantine "$STAGING_APP" >/dev/null 2>&1 || true

echo "Re-signing the copied app..."
codesign --force --deep --sign - "$STAGING_APP"
codesign --verify --deep --strict "$STAGING_APP"

echo "Activating the Chinese copy..."
OLD_APP="$TARGET_DIR/.$DISPLAY_NAME.app.previous"
rm -rf "$OLD_APP"
if [[ -d "$TARGET_APP" ]]; then
  mv "$TARGET_APP" "$OLD_APP"
fi

if ! mv "$STAGING_APP" "$TARGET_APP"; then
  if [[ -d "$OLD_APP" && ! -d "$TARGET_APP" ]]; then
    mv "$OLD_APP" "$TARGET_APP"
  fi
  echo "ERROR: Failed to activate the Chinese app copy."
  read "?Press Enter to close"
  exit 1
fi
rm -rf "$OLD_APP"

echo ""
echo "恭喜，ChatGPT / Codex 汉化成功！"
echo "作者：大瑜"
echo "微信号：helloaigc2023"
echo "欢迎关注，分享更多 AI 资讯和信息。"
echo ""
echo "Open this app:"
echo "$TARGET_APP"
echo ""
if [[ "$PRODUCT_NAME" == "ChatGPT" ]]; then
  echo "After opening ChatGPT Zh, choose Codex from the top-left mode menu."
fi
echo "If macOS blocks it, right-click '$DISPLAY_NAME.app' and choose Open."
read "?Press Enter to close"
