#!/usr/bin/env python3
import hashlib
import json
import os
import plistlib
import shutil
import struct
import sys
from pathlib import Path


def log(message):
    print(f"[codex-i18n] {message}")


def die(message):
    print(f"[codex-i18n] ERROR: {message}", file=sys.stderr)
    sys.exit(1)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read_asar(path):
    blob = Path(path).read_bytes()
    if len(blob) < 16:
        die("Invalid app.asar")
    header_size = struct.unpack_from("<I", blob, 4)[0]
    json_len = struct.unpack_from("<I", blob, 12)[0]
    data_start = 8 + header_size
    header_json = blob[16 : 16 + json_len]
    header = json.loads(header_json.decode("utf-8"))
    return blob, header, header_json, data_start


def walk_files(node, prefix=""):
    for name, child in (node.get("files") or {}).items():
        current = f"{prefix}/{name}" if prefix else name
        if "files" in child:
            yield from walk_files(child, current)
        else:
            yield current, child


def get_node(header, file_path):
    node = {"files": header.get("files", {})}
    for part in file_path.split("/"):
        node = (node.get("files") or {}).get(part)
        if node is None:
            return None
    return node


def read_file(blob, header, data_start, file_path):
    node = get_node(header, file_path)
    if node is None or "files" in node:
        return None
    offset = int(node.get("offset") or 0)
    size = int(node.get("size") or 0)
    return blob[data_start + offset : data_start + offset + size]


def update_integrity(node, content):
    if "integrity" not in node:
        return
    block_size = node["integrity"].get("blockSize") or 4 * 1024 * 1024
    blocks = [
        sha256(content[index : index + block_size])
        for index in range(0, len(content), block_size)
    ]
    if not blocks:
        blocks = [sha256(b"")]
    node["integrity"] = {
        "algorithm": "SHA256",
        "hash": sha256(content),
        "blockSize": block_size,
        "blocks": blocks,
    }


def patch_source(source):
    replacements = [
        ("get(`enable_i18n`,!1)", "get(`enable_i18n`,!0)"),
        ('get("enable_i18n",!1)', 'get("enable_i18n",!0)'),
        ("get('enable_i18n',!1)", "get('enable_i18n',!0)"),
        ("get(`enable_i18n`,false)", "get(`enable_i18n`,true )"),
        ('get("enable_i18n",false)', 'get("enable_i18n",true )'),
        ("get('enable_i18n',false)", "get('enable_i18n',true )"),
    ]
    count = 0
    next_source = source
    for old, new in replacements:
        hits = next_source.count(old)
        if hits:
            count += hits
            next_source = next_source.replace(old, new)
    return next_source, count


def replace_header_hashes_in_place(header_json, updated_nodes):
    text = header_json.decode("utf-8")
    for before, after in updated_nodes:
        before_integrity = before.get("integrity")
        after_integrity = after.get("integrity")
        if not before_integrity or not after_integrity:
            continue
        before_blocks = before_integrity.get("blocks") or []
        after_blocks = after_integrity.get("blocks") or []
        if len(before_blocks) != len(after_blocks):
            die("Cannot update ASAR integrity in place because block count changed.")
        pairs = [(before_integrity.get("hash"), after_integrity.get("hash"))]
        pairs.extend(zip(before_blocks, after_blocks))
        seen_old_hashes = set()
        for old_hash, new_hash in pairs:
            if not old_hash or not new_hash or len(old_hash) != len(new_hash):
                die("Cannot update ASAR integrity in place because hash length changed.")
            if old_hash in seen_old_hashes:
                continue
            seen_old_hashes.add(old_hash)
            if old_hash not in text:
                die(f"Cannot find old integrity hash in ASAR header: {old_hash}")
            text = text.replace(old_hash, new_hash)
    next_header = text.encode("utf-8")
    if len(next_header) != len(header_json):
        die("Cannot update ASAR header in place because header length changed.")
    return next_header


def write_asar_in_place(path, blob, header, header_json, data_start, replacements):
    output = bytearray(blob)
    updated_nodes = []

    for file_path, content in replacements.items():
        node = get_node(header, file_path)
        if node is None or "files" in node:
            die(f"ASAR node not found for replacement: {file_path}")
        original = read_file(blob, header, data_start, file_path)
        if len(original) != len(content):
            die(f"Replacement length changed for {file_path}. Refusing to rewrite ASAR container.")

        start = data_start + int(node.get("offset") or 0)
        output[start : start + len(content)] = content

        before = json.loads(json.dumps(node))
        update_integrity(node, content)
        after = json.loads(json.dumps(node))
        updated_nodes.append((before, after))

    patched_header = replace_header_hashes_in_place(header_json, updated_nodes)
    output[16 : 16 + len(patched_header)] = patched_header
    Path(path).write_bytes(output)


def asar_header_hash(path):
    blob = Path(path).read_bytes()
    if len(blob) < 16:
        die("Invalid app.asar")
    json_len = struct.unpack_from("<I", blob, 12)[0]
    return sha256(blob[16 : 16 + json_len])


def update_info_plist(info_plist_path, header_hash, display_name):
    path = Path(info_plist_path)
    if not path.exists():
        die(f"Info.plist not found: {path}")

    raw = path.read_bytes()
    plist_format = plistlib.FMT_BINARY if raw.startswith(b"bplist") else plistlib.FMT_XML
    info = plistlib.loads(raw)
    integrity = info.setdefault("ElectronAsarIntegrity", {})
    app_asar = integrity.setdefault("Resources/app.asar", {})
    app_asar["algorithm"] = "SHA256"
    app_asar["hash"] = header_hash

    if display_name:
        info["CFBundleDisplayName"] = display_name
        info["CFBundleName"] = display_name
        alternate_names = list(info.get("CFBundleAlternateNames") or [])
        if display_name not in alternate_names:
            alternate_names.insert(0, display_name)
        info["CFBundleAlternateNames"] = alternate_names

    path.write_bytes(plistlib.dumps(info, fmt=plist_format, sort_keys=False))
    log(f"updated Info.plist ASAR integrity: {header_hash}")


def main():
    if len(sys.argv) < 2:
        die(
            "Usage: enable_codex_i18n.py <path-to-app.asar> "
            "[--info-plist <path>] [--display-name <name>]"
        )
    asar_path = Path(sys.argv[1])
    info_plist_path = None
    display_name = None
    index = 2
    while index < len(sys.argv):
        option = sys.argv[index]
        if option == "--info-plist" and index + 1 < len(sys.argv):
            info_plist_path = sys.argv[index + 1]
            index += 2
        elif option == "--display-name" and index + 1 < len(sys.argv):
            display_name = sys.argv[index + 1]
            index += 2
        else:
            die(f"Unknown or incomplete option: {option}")

    if not asar_path.exists():
        die(f"app.asar not found: {asar_path}")

    blob, header, header_json, data_start = read_asar(asar_path)
    replacements = {}
    total = 0
    already_enabled = False

    for file_path, _ in walk_files(header):
        if not file_path.endswith(".js"):
            continue
        content = read_file(blob, header, data_start, file_path)
        if content is None:
            continue
        try:
            source = content.decode("utf-8")
        except UnicodeDecodeError:
            continue
        if "enable_i18n" not in source:
            continue
        if (
            "get(`enable_i18n`,!0)" in source
            or 'get("enable_i18n",!0)' in source
            or "get('enable_i18n',!0)" in source
            or "get(`enable_i18n`,true)" in source
            or 'get("enable_i18n",true)' in source
            or "get('enable_i18n',true)" in source
            or "get(`enable_i18n`,true )" in source
            or 'get("enable_i18n",true )' in source
            or "get('enable_i18n',true )" in source
        ):
            already_enabled = True
        next_source, count = patch_source(source)
        if count:
            next_content = next_source.encode("utf-8")
            if len(next_content) != len(content):
                die(f"Patched source length changed for {file_path}. This build needs a new in-place pattern.")
            replacements[file_path] = next_content
            total += count
            log(f"patched {file_path}: {count}")
        else:
            log(f"found enable_i18n but no false default pattern in {file_path}")

    if total == 0:
        if already_enabled:
            log("enable_i18n already defaults to true.")
        else:
            die(
                "No enable_i18n false default was patched. "
                "This ChatGPT/Codex version may use a different pattern."
            )
    else:
        backup = Path(str(asar_path) + ".bak-before-i18n")
        if not backup.exists():
            shutil.copy2(asar_path, backup)
            log(f"backup: {backup}")

        write_asar_in_place(asar_path, blob, header, header_json, data_start, replacements)
        log(f"done, patched replacements: {total}")

    if info_plist_path:
        update_info_plist(info_plist_path, asar_header_hash(asar_path), display_name)


if __name__ == "__main__":
    main()
