#!/bin/zsh
set -euo pipefail

CHATGPT_TARGET="$HOME/Applications/ChatGPT Zh.app"
CODEX_TARGET="$HOME/Applications/Codex Zh.app"

echo ""
echo "== Remove ChatGPT / Codex Chinese copy for macOS =="
echo ""

osascript -e 'tell application "ChatGPT Zh" to quit' >/dev/null 2>&1 || true
osascript -e 'tell application "Codex Zh" to quit' >/dev/null 2>&1 || true
pkill -x "ChatGPT" >/dev/null 2>&1 || true
pkill -x "Codex" >/dev/null 2>&1 || true

rm -rf "$CHATGPT_TARGET" "$CODEX_TARGET"

echo "Removed Chinese copies under: $HOME/Applications"
echo "The official app under /Applications was not changed."
read "?Press Enter to close"
