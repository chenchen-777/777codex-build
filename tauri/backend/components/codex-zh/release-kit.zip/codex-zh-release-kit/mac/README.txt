ChatGPT / Codex Chinese UI - macOS

How to use:

1. Install the official ChatGPT desktop app first.
2. Open the official app once and confirm it works.
3. Quit ChatGPT/Codex completely.
4. Open this mac folder.
5. Right-click install-mac.command and choose Open.
6. After it finishes, open:

   ~/Applications/ChatGPT Zh.app

7. In ChatGPT Zh, choose Codex from the top-left mode menu.

Compatibility:

- New unified app: /Applications/ChatGPT.app
- Legacy app: /Applications/Codex.app

If macOS says it cannot verify install-mac.command:

1. Do not move it to Trash; click Done.
2. Right-click install-mac.command and choose Open.
3. Click Open again.
4. If it is still blocked, go to System Settings > Privacy & Security and choose Open Anyway.

Uninstall:

Right-click uninstall-mac.command and choose Open.

Notes:

- The official app under /Applications is not overwritten.
- A copied Chinese app is created under ~/Applications.
- After the official app updates, run install-mac.command again.
