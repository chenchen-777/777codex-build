@echo off
setlocal
pushd "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%CD%\uninstall-user-copy.ps1"
popd

