Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

function Step {
  param([string]$Message)
  Write-Host ""
  Write-Host "== $Message ==" -ForegroundColor Cyan
}

function Write-TextUtf8NoBom {
  param([string]$Path, [string]$Value)
  $encoding = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $Value, $encoding)
}

function Write-TextUnicode {
  param([string]$Path, [string]$Value)
  [System.IO.File]::WriteAllText($Path, $Value, [System.Text.Encoding]::Unicode)
}

function Get-LocalAppData {
  $value = [Environment]::GetFolderPath("LocalApplicationData")
  if (-not $value) { $value = $env:LOCALAPPDATA }
  if (-not $value) { $value = Join-Path $env:USERPROFILE "AppData\Local" }
  return $value
}

function Get-DesktopPath {
  $value = [Environment]::GetFolderPath("Desktop")
  if (-not $value) { $value = $env:USERPROFILE }
  return $value
}

function Get-ExactInstallRoot {
  param([string]$SelectedPath)
  $path = $SelectedPath.Trim().Trim('"')
  if (-not $path) { throw "Install path is empty." }
  return [System.IO.Path]::GetFullPath($path)
}

function Get-SafeInstallRoot {
  param([string]$SelectedPath)
  $fullPath = Get-ExactInstallRoot $SelectedPath
  $leaf = Split-Path -Leaf $fullPath
  if ($leaf -ieq "CodexZh" -or $leaf -ieq "ChatGPTZh") { return $fullPath }
  return (Join-Path $fullPath "CodexZh")
}

function Select-FolderByDialog {
  param([string]$DefaultPath)
  try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "Select a folder for ChatGPT / Codex Chinese UI. A CodexZh folder will be created inside it."
    $dialog.SelectedPath = $DefaultPath
    $dialog.ShowNewFolderButton = $true
    $result = $dialog.ShowDialog()
    if ($result -ne [System.Windows.Forms.DialogResult]::OK -or -not $dialog.SelectedPath) {
      throw "No folder was selected."
    }
    return (Get-SafeInstallRoot $dialog.SelectedPath)
  } catch {
    throw "Folder picker failed or was canceled. Run install.bat again and choose option 1 or 3. Details: $($_.Exception.Message)"
  }
}

function Select-InstallRoot {
  param(
    [string]$DefaultRoot,
    [bool]$IsPreviousInstall
  )
  Write-Host ""
  Write-Host "Choose install location:"
  if ($IsPreviousInstall) {
    Write-Host "1. Keep previous install location (recommended)"
  } else {
    Write-Host "1. Default install (recommended)"
  }
  Write-Host "   $DefaultRoot"
  Write-Host "2. Choose folder with popup"
  Write-Host "3. Type install path manually, for example D:\CodexZh"
  Write-Host ""
  $choice = Read-Host "Enter 1 / 2 / 3, or press Enter for 1"
  if (-not $choice) { $choice = "1" }
  switch ($choice.Trim()) {
    "1" { return $DefaultRoot }
    "2" { return (Select-FolderByDialog (Split-Path -Parent $DefaultRoot)) }
    "3" {
      $manual = Read-Host "Enter install folder, for example D:\CodexZh"
      return (Get-ExactInstallRoot $manual)
    }
    default { throw "Invalid choice: $choice" }
  }
}

function Get-PreviousInstallRoot {
  param(
    [string]$StatePath,
    [string]$DesktopPath
  )

  $candidates = New-Object System.Collections.Generic.List[string]
  if (Test-Path -LiteralPath $StatePath) {
    try {
      $savedPath = (Get-Content -LiteralPath $StatePath -Raw -ErrorAction Stop).Trim().Trim('"')
      if ($savedPath) { $candidates.Add($savedPath) }
    } catch {}
  }

  try {
    $shell = New-Object -ComObject WScript.Shell
    foreach ($shortcutName in @("ChatGPT Zh.lnk", "Codex Zh.lnk")) {
      $shortcutPath = Join-Path $DesktopPath $shortcutName
      if (-not (Test-Path -LiteralPath $shortcutPath)) { continue }
      $shortcut = $shell.CreateShortcut($shortcutPath)
      $launcherPath = ([string]$shortcut.Arguments).Trim().Trim('"')
      $launcherName = if ($launcherPath) { Split-Path -Leaf $launcherPath } else { "" }
      if ($launcherName -in @("Launch Chinese UI.vbs", "Launch Codex Zh.vbs", "Launch ChatGPT Zh.vbs")) {
        $candidates.Add((Split-Path -Parent $launcherPath))
      }
    }
  } catch {}

  foreach ($candidate in $candidates) {
    try {
      if (-not [System.IO.Path]::IsPathRooted($candidate)) { continue }
      $fullPath = [System.IO.Path]::GetFullPath($candidate)
      $driveRoot = [System.IO.Path]::GetPathRoot($fullPath)
      if (-not $driveRoot -or -not (Test-Path -LiteralPath $driveRoot)) { continue }
      $hasInstall =
        (Test-Path -LiteralPath (Join-Path $fullPath "install-info.json")) -or
        (Test-Path -LiteralPath (Join-Path $fullPath "Launch Chinese UI.vbs")) -or
        (Test-Path -LiteralPath (Join-Path $fullPath "app\resources\app.asar"))
      if ($hasInstall) { return $fullPath }
    } catch {}
  }

  return $null
}

function Log-Install {
  param([string]$Message)
  $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message
  try { Add-Content -LiteralPath $installLog -Value $line -Encoding UTF8 } catch {}
  if ($installLogCopy) {
    try { Add-Content -LiteralPath $installLogCopy -Value $line -Encoding UTF8 } catch {}
  }
}

function Write-Utf8Base64Line {
  param([string]$Value, [string]$Color = "")
  $text = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($Value))
  if ($Color) {
    Write-Host $text -ForegroundColor $Color
  } else {
    Write-Host $text
  }
}

function Find-OfficialDesktopApp {
  $packages = @()
  foreach ($packageName in @("OpenAI.Codex", "OpenAI.ChatGPT")) {
    $packages += @(Get-AppxPackage -Name $packageName -ErrorAction SilentlyContinue)
  }

  if ($packages.Count -eq 0) {
    $packages = @(Get-AppxPackage -ErrorAction SilentlyContinue | Where-Object {
      $_.Name -match "OpenAI|Codex|ChatGPT"
    })
  }

  foreach ($pkg in @($packages | Sort-Object Version -Descending)) {
    if (-not $pkg.InstallLocation) { continue }
    $roots = @((Join-Path $pkg.InstallLocation "app"), $pkg.InstallLocation)
    foreach ($sourceRoot in $roots) {
      $sourceAsar = Join-Path $sourceRoot "resources\app.asar"
      if (-not (Test-Path -LiteralPath $sourceAsar)) { continue }
      foreach ($exeName in @("ChatGPT.exe", "Codex.exe")) {
        $sourceExe = Join-Path $sourceRoot $exeName
        if (Test-Path -LiteralPath $sourceExe) {
          $productName = if ($exeName -ieq "ChatGPT.exe") { "ChatGPT" } else { "Codex" }
          try {
            $manifest = Get-AppxPackageManifest -Package $pkg.PackageFullName -ErrorAction Stop
            $manifestDisplayName = [string]$manifest.Package.Applications.Application.VisualElements.DisplayName
            if ($manifestDisplayName -match "ChatGPT") { $productName = "ChatGPT" }
          } catch {}
          return [PSCustomObject]@{
            Package = $pkg
            SourceApp = $sourceRoot
            ExeName = $exeName
            ProductName = $productName
          }
        }
      }
    }
  }

  throw "The official ChatGPT desktop app was not found. Install it from Microsoft Store first and confirm that it can open."
}

function Stop-PatchedProcesses {
  param([string]$TargetApp)
  foreach ($processName in @("ChatGPT", "Codex")) {
    Get-Process -Name $processName -ErrorAction SilentlyContinue | ForEach-Object {
      $processPath = $null
      try { $processPath = $_.Path } catch {}
      if ($processPath -and $processPath.StartsWith($TargetApp, [System.StringComparison]::OrdinalIgnoreCase)) {
        Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
      }
    }
  }
}

function Clear-EncryptionFlag {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { return }
  Log-Install "Clearing EFS encryption flag if present: $Path"
  try {
    & "$env:WINDIR\System32\cipher.exe" /D $Path 2>&1 | ForEach-Object {
      Log-Install "cipher: $_"
    }
  } catch {
    Log-Install "cipher failed for ${Path}: $($_.Exception.Message)"
  }
}

function Assert-UnencryptedWritableDirectory {
  param([string]$Path)
  New-Item -ItemType Directory -Force -Path $Path | Out-Null
  $testPath = Join-Path $Path (".codex-zh-write-test-{0}.tmp" -f $PID)
  try {
    [System.IO.File]::WriteAllText($testPath, "codex-zh-test", [System.Text.Encoding]::ASCII)
    $directoryAttributes = (Get-Item -LiteralPath $Path -Force).Attributes
    $fileAttributes = (Get-Item -LiteralPath $testPath -Force).Attributes
    $encryptedFlag = [System.IO.FileAttributes]::Encrypted
    if (($directoryAttributes -band $encryptedFlag) -ne 0 -or ($fileAttributes -band $encryptedFlag) -ne 0) {
      throw "EFS_ENCRYPTED_TARGET"
    }
  } catch {
    if ($_.Exception.Message -eq "EFS_ENCRYPTED_TARGET") {
      throw "The selected install folder uses Windows EFS encryption. Choose an unencrypted folder such as C:\CodexZh or D:\CodexZh, or follow efs-fix-guide.pdf before trying again."
    }
    throw "The selected install folder is not writable: $Path. Details: $($_.Exception.Message)"
  } finally {
    Remove-Item -LiteralPath $testPath -Force -ErrorAction SilentlyContinue
  }
}

function Copy-OfficialApp {
  param(
    [string]$SourceApp,
    [string]$DestinationApp,
    [string]$ExeName
  )

  if (Test-Path -LiteralPath $DestinationApp) {
    Remove-Item -LiteralPath $DestinationApp -Recurse -Force -ErrorAction Stop
  }
  New-Item -ItemType Directory -Force -Path $DestinationApp | Out-Null
  Assert-UnencryptedWritableDirectory $DestinationApp

  $robocopy = Join-Path $env:WINDIR "System32\robocopy.exe"
  $robocopyArgs = @(
    $SourceApp,
    $DestinationApp,
    "/MIR",
    "/COPY:D",
    "/DCOPY:D",
    "/IS",
    "/IT",
    "/R:1",
    "/W:1",
    "/NFL",
    "/NDL",
    "/NP"
  )
  & $robocopy @robocopyArgs
  $robocopyExit = $LASTEXITCODE
  Log-Install "robocopy exit code: $robocopyExit"

  $copiedExe = Join-Path $DestinationApp $ExeName
  $copiedAsar = Join-Path $DestinationApp "resources\app.asar"
  if ($robocopyExit -gt 7 -or -not (Test-Path -LiteralPath $copiedExe) -or -not (Test-Path -LiteralPath $copiedAsar)) {
    Log-Install "robocopy did not produce a complete app. Trying Copy-Item fallback."
    Write-Host "Primary copy was incomplete. Trying fallback copy..." -ForegroundColor Yellow
    try {
      Copy-Item -Path (Join-Path $SourceApp "*") -Destination $DestinationApp -Recurse -Force -ErrorAction Stop
    } catch {
      Log-Install "Copy-Item fallback failed: $($_.Exception.Message)"
    }
  }

  if (-not (Test-Path -LiteralPath $copiedExe) -or -not (Test-Path -LiteralPath $copiedAsar)) {
    throw "ChatGPT files were not copied correctly. If the log shows error 6000 or 'The specified file could not be encrypted', follow efs-fix-guide.pdf or choose an unencrypted folder such as C:\CodexZh or D:\CodexZh."
  }
}

$localAppData = Get-LocalAppData
$desktop = Get-DesktopPath
$installLog = Join-Path $desktop "codex-zh-install.log"
$installLogCopy = $null
Remove-Item -LiteralPath $installLog -Force -ErrorAction SilentlyContinue
Log-Install "ChatGPT / Codex Chinese UI installer started"
Log-Install "User: $env:USERNAME"
Log-Install "PowerShell: $($PSVersionTable.PSVersion)"
Log-Install "Installer folder: $Root"

$installerStateRoot = Join-Path $localAppData "OpenAI\CodexZhInstaller"
$installPathFile = Join-Path $installerStateRoot "install-path.txt"
$standardDefaultRoot = Join-Path $localAppData "OpenAI\CodexZh"
$previousRoot = Get-PreviousInstallRoot -StatePath $installPathFile -DesktopPath $desktop
$defaultRoot = if ($previousRoot) { $previousRoot } else { $standardDefaultRoot }
if ($previousRoot) { Log-Install "Previous install detected: $previousRoot" }
$targetRoot = Select-InstallRoot -DefaultRoot $defaultRoot -IsPreviousInstall ([bool]$previousRoot)
$targetLogDir = Join-Path $targetRoot "logs"
$installLogCopy = Join-Path $targetLogDir "codex-zh-install.log"
New-Item -ItemType Directory -Force -Path $targetRoot, $targetLogDir, $installerStateRoot | Out-Null
Remove-Item -LiteralPath $installLogCopy -Force -ErrorAction SilentlyContinue
Log-Install "Target root: $targetRoot"
Write-TextUtf8NoBom -Path $installPathFile -Value $targetRoot
Log-Install "Install path file: $installPathFile"

try {
  Step "Find official ChatGPT / Codex"
  $official = Find-OfficialDesktopApp
  $pkg = $official.Package
  $sourceApp = $official.SourceApp
  $exeName = $official.ExeName
  $productName = $official.ProductName
  Write-Host "Package: $($pkg.Name) $($pkg.Version)"
  Write-Host "Source: $sourceApp"
  Write-Host "Executable: $exeName"
  Log-Install "Package: $($pkg.Name) $($pkg.Version)"
  Log-Install "Source: $sourceApp"
  Log-Install "Executable: $exeName"

  Step "Prepare install folder"
  $targetApp = Join-Path $targetRoot "app"
  $stagingApp = Join-Path $targetRoot "app.installing"
  $previousApp = Join-Path $targetRoot "app.previous"
  $targetData = Join-Path $targetRoot "electron-user-data"
  New-Item -ItemType Directory -Force -Path $targetRoot, $targetData, $targetLogDir | Out-Null
  Clear-EncryptionFlag $targetRoot
  Clear-EncryptionFlag $targetData
  Assert-UnencryptedWritableDirectory $targetRoot
  Assert-UnencryptedWritableDirectory $targetData
  Stop-PatchedProcesses $targetApp

  Step "Copy official app"
  Copy-OfficialApp -SourceApp $sourceApp -DestinationApp $stagingApp -ExeName $exeName
  & "$env:WINDIR\System32\attrib.exe" -R (Join-Path $stagingApp "*") /S /D 2>$null

  Step "Enable Chinese UI"
  $stagingExe = Join-Path $stagingApp $exeName
  $stagingAsar = Join-Path $stagingApp "resources\app.asar"
  $node = Join-Path $stagingApp "resources\cua_node\bin\node.exe"
  if (-not (Test-Path -LiteralPath $node)) {
    $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
    if (-not $nodeCmd) {
      throw "Node.js was not found. The bundled node.exe was also missing."
    }
    $node = $nodeCmd.Source
  }

  $patcher = Join-Path $Root "tools\enable-codex-i18n.js"
  & $node $patcher $stagingAsar --exe $stagingExe 2>&1 | Tee-Object -FilePath $installLog -Append | Out-Host
  if ($LASTEXITCODE -ne 0) {
    throw "Failed to patch the ChatGPT / Codex Chinese UI."
  }
  Log-Install "Patch exit code: $LASTEXITCODE"
  Remove-Item -LiteralPath "$stagingAsar.bak-before-i18n", "$stagingExe.bak-before-i18n" -Force -ErrorAction SilentlyContinue

  Step "Activate Chinese copy"
  Stop-PatchedProcesses $targetApp
  Remove-Item -LiteralPath $previousApp -Recurse -Force -ErrorAction SilentlyContinue
  if (Test-Path -LiteralPath $targetApp) {
    Move-Item -LiteralPath $targetApp -Destination $previousApp -Force
  }
  try {
    Move-Item -LiteralPath $stagingApp -Destination $targetApp -Force
  } catch {
    if ((Test-Path -LiteralPath $previousApp) -and -not (Test-Path -LiteralPath $targetApp)) {
      Move-Item -LiteralPath $previousApp -Destination $targetApp -Force
    }
    throw
  }
  Remove-Item -LiteralPath $previousApp -Recurse -Force -ErrorAction SilentlyContinue

  $targetExe = Join-Path $targetApp $exeName
  $targetAsar = Join-Path $targetApp "resources\app.asar"
  if (-not (Test-Path -LiteralPath $targetExe) -or -not (Test-Path -LiteralPath $targetAsar)) {
    throw "Activation check failed. The previous working copy was preserved when possible."
  }

  $installInfo = [ordered]@{
    ProductName = $productName
    ExeName = $exeName
    PackageName = $pkg.Name
    PackageVersion = $pkg.Version.ToString()
    TargetRoot = $targetRoot
    InstalledAt = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
  } | ConvertTo-Json
  Write-TextUtf8NoBom -Path (Join-Path $targetRoot "install-info.json") -Value $installInfo

  Step "Create launcher"
  $shortcutBase = if ($productName -eq "ChatGPT") { "ChatGPT Zh" } else { "Codex Zh" }
  $launcherVbs = Join-Path $targetRoot "Launch Chinese UI.vbs"
  $debugPs1 = Join-Path $targetRoot "Debug Chinese UI.ps1"
  $desktopShortcut = Join-Path $desktop "$shortcutBase.lnk"
  $desktopDebug = Join-Path $desktop "Debug $shortcutBase.bat"

  foreach ($oldShortcut in @(
    (Join-Path $desktop "Codex Zh.lnk"),
    (Join-Path $desktop "ChatGPT Zh.lnk"),
    (Join-Path $desktop "Open Codex Zh.bat"),
    (Join-Path $desktop "Open ChatGPT Zh.bat"),
    (Join-Path $desktop "Debug Codex Zh.bat"),
    (Join-Path $desktop "Debug ChatGPT Zh.bat")
  )) {
    if ($oldShortcut -ne $desktopShortcut -and $oldShortcut -ne $desktopDebug) {
      Remove-Item -LiteralPath $oldShortcut -Force -ErrorAction SilentlyContinue
    }
  }

$vbsContent = @"
Set shell = CreateObject("WScript.Shell")
Set env = shell.Environment("PROCESS")
Set fso = CreateObject("Scripting.FileSystemObject")
exePath = "$targetExe"
userDataPath = "$targetData"
If Not fso.FileExists(exePath) Then
  MsgBox "The Chinese app copy is incomplete. Please run install.bat again.", 16, "ChatGPT Chinese UI"
  WScript.Quit 2
End If
q = Chr(34)
env("CODEX_HOME") = shell.ExpandEnvironmentStrings("%USERPROFILE%") & "\.codex"
env("CODEX_ELECTRON_USER_DATA_PATH") = userDataPath
env("ELECTRON_LOCALE_OVERRIDE") = "zh-CN"
shell.CurrentDirectory = "$targetApp"
cmd = q & exePath & q & " " & q & "--user-data-dir=" & userDataPath & q & " " & q & "--lang=zh-CN" & q
shell.Run cmd, 1, False
"@
  Write-TextUnicode -Path $launcherVbs -Value $vbsContent
  Copy-Item -LiteralPath (Join-Path $Root "debug-launch.ps1") -Destination $debugPs1 -Force

$debugBatContent = @"
@echo off
setlocal
set "BOOTDIR=%TEMP%"
if not defined BOOTDIR set "BOOTDIR=%LOCALAPPDATA%\OpenAI\CodexZhInstaller"
if not exist "%BOOTDIR%\" (
  set "BOOTDIR=%LOCALAPPDATA%\OpenAI\CodexZhInstaller"
  if not exist "%LOCALAPPDATA%\OpenAI\CodexZhInstaller\" mkdir "%LOCALAPPDATA%\OpenAI\CodexZhInstaller" >nul 2>&1
)
if not exist "%BOOTDIR%\" set "BOOTDIR=%~dp0"
set "BOOTLOG=%BOOTDIR%\codex-zh-debug-bootstrap.log"
echo [%DATE% %TIME%] desktop debug launcher started>"%BOOTLOG%"
echo Install root: $targetRoot>>"%BOOTLOG%"
where powershell.exe >>"%BOOTLOG%" 2>&1
if errorlevel 1 (
  echo powershell.exe not found>>"%BOOTLOG%"
  echo PowerShell not found. Log: "%BOOTLOG%"
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$debugPs1"
set "RC=0"
if errorlevel 1 set "RC=1"
echo [%DATE% %TIME%] desktop debug launcher finished, exit code %RC%>>"%BOOTLOG%"
if not "%RC%"=="0" pause
exit /b %RC%
"@
  Write-TextUtf8NoBom -Path $desktopDebug -Value $debugBatContent

  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut($desktopShortcut)
  $shortcut.TargetPath = "$env:WINDIR\System32\wscript.exe"
  $shortcut.Arguments = "`"$launcherVbs`""
  $shortcut.WorkingDirectory = $targetRoot
  $shortcut.IconLocation = $targetExe
  $shortcut.Description = "ChatGPT / Codex Chinese UI"
  $shortcut.Save()

  Step "Done"
  Log-Install "Installed to: $targetRoot"
  Log-Install "Desktop shortcut: $desktopShortcut"
  Log-Install "Debug launcher: $desktopDebug"
  Copy-Item -LiteralPath $installLog -Destination $installLogCopy -Force -ErrorAction SilentlyContinue
  Write-Host "Installed to: $targetRoot"
  Write-Host "Desktop shortcut: $desktopShortcut"
  Write-Host "Debug launcher: $desktopDebug"
  Write-Host "Install log: $installLog"
  Write-Host ""
  Write-Utf8Base64Line "5oGt5Zac77yMQ2hhdEdQVCAvIENvZGV4IOaxieWMluaIkOWKn++8gQ==" "Green"
  Write-Utf8Base64Line "5L2c6ICF77ya5aSn55Gc"
  Write-Utf8Base64Line "5b6u5L+h5Y+377yaaGVsbG9haWdjMjAyMw=="
  Write-Utf8Base64Line "5qyi6L+O5YWz5rOo77yM5YiG5Lqr5pu05aSaIEFJIOi1hOiur+WSjOS/oeaBr+OAgg=="
  Write-Host ""
  if ($productName -eq "ChatGPT") {
    Write-Host "Open ChatGPT Zh, then choose Codex from the top-left mode menu." -ForegroundColor Green
  } else {
    Write-Host "Open Codex Zh from the desktop." -ForegroundColor Green
  }
} catch {
  Log-Install "ERROR: $($_.Exception.Message)"
  try { Copy-Item -LiteralPath $installLog -Destination $installLogCopy -Force -ErrorAction SilentlyContinue } catch {}
  Write-Host ""
  Write-Host "Install failed: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host "Install log: $installLog"
  Write-Host "Backup log: $installLogCopy"
  Read-Host "Press Enter to close"
  exit 1
}

Read-Host "Press Enter to close"
