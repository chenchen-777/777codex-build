# ChatGPT / Codex Chinese UI User-Copy Kit

本包兼容 2026 年 7 月后的 ChatGPT 桌面应用，也兼容旧版独立 Codex Desktop。

新版本里，Codex 已经放进 ChatGPT 桌面应用。汉化完成后，请打开桌面的 `ChatGPT Zh`，再从左上角模式菜单选择 `Codex`。

## 小白安装步骤

1. 先安装官方 ChatGPT 桌面应用，并确认官方应用能够正常打开。
2. 关闭 ChatGPT / Codex。
3. 解压本压缩包，打开 `win` 文件夹。
4. 双击 `install.bat`。
5. 安装位置直接按回车，选择默认安装。
6. 安装完成后，打开桌面的 `ChatGPT Zh` 或 `Codex Zh`。

安装器会自动识别新旧版本，不需要用户判断 `ChatGPT.exe` 还是 `Codex.exe`。

## 安装位置

- `1` 或直接回车：首次安装使用默认位置；重新安装或更新时会优先沿用上一次的 C 盘或 D 盘目录。
- `2`：弹窗选择文件夹，例如 D 盘。
- `3`：手动输入完整路径，例如 `F:\AI工具\中文Codex`。程序不会在后面额外添加 `CodexZh`。

建议选择未开启 Windows EFS 加密的目录。若出现错误 6000 或“无法加密指定的文件”，请阅读根目录的 `efs-fix-guide.pdf`。

## 打不开怎么办

双击桌面的 `Debug ChatGPT Zh.bat` 或 `Debug Codex Zh.bat`，然后发送：

- `codex-zh-install.log`
- `codex-zh-debug.log`

如果安装器刚启动就退出，再补充发送 `codex-zh-install-bootstrap.log`。它通常位于 `%TEMP%`；如果临时目录无效，会自动保存到 `%LOCALAPPDATA%\OpenAI\CodexZhInstaller`。调试启动器日志同理。

## 卸载

双击 `uninstall.bat`。

卸载只删除用户目录中的中文副本和快捷方式，不会删除或修改官方 Microsoft Store 应用。

## 说明

- 官方应用更新后，需要重新运行一次 `install.bat`。
- 安装器先在临时目录完成复制、检查和汉化，成功后才替换旧中文副本。
- 这个包只处理界面语言，不负责 API、账号或网络连接问题。
