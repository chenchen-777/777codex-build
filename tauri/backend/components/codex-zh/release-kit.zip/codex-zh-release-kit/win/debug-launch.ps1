Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

function Get-LocalAppData {
  $value = [Environment]::GetFolderPath("LocalApplicationData")
  if (-not $value) { $value = $env:LOCALAPPDATA }
  if (-not $value) { $value = Join-Path $env:USERPROFILE "AppData\Local" }
  return $value
}

$localAppData = Get-LocalAppData
$installPathFile = Join-Path $localAppData "OpenAI\CodexZhInstaller\install-path.txt"
$defaultRoot = Join-Path $localAppData "OpenAI\CodexZh"
if (Test-Path -LiteralPath $installPathFile) {
  $configuredRoot = (Get-Content -LiteralPath $installPathFile -Raw -ErrorAction SilentlyContinue).Trim()
  $targetRoot = if ($configuredRoot) { $configuredRoot } else { $defaultRoot }
} else {
  $targetRoot = $defaultRoot
}

$targetApp = Join-Path $targetRoot "app"
$targetData = Join-Path $targetRoot "electron-user-data"
$targetLogDir = Join-Path $targetRoot "logs"
$installInfoPath = Join-Path $targetRoot "install-info.json"
$exeName = $null
$productName = "ChatGPT / Codex"

if (Test-Path -LiteralPath $installInfoPath) {
  try {
    $installInfo = Get-Content -LiteralPath $installInfoPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $exeName = [string]$installInfo.ExeName
    $productName = [string]$installInfo.ProductName
  } catch {}
}

if (-not $exeName) {
  foreach ($candidate in @("ChatGPT.exe", "Codex.exe")) {
    if (Test-Path -LiteralPath (Join-Path $targetApp $candidate)) {
      $exeName = $candidate
      break
    }
  }
}
if (-not $exeName) { $exeName = "ChatGPT.exe" }
$exe = Join-Path $targetApp $exeName

$desktop = [Environment]::GetFolderPath("Desktop")
if (-not $desktop) { $desktop = $env:USERPROFILE }
$log = Join-Path $desktop "codex-zh-debug.log"
$logCopy = Join-Path $targetLogDir "codex-zh-debug.log"
$stdoutLog = Join-Path $desktop "codex-zh-stdout.log"
$stderrLog = Join-Path $desktop "codex-zh-stderr.log"
$stdoutLogCopy = Join-Path $targetLogDir "codex-zh-stdout.log"
$stderrLogCopy = Join-Path $targetLogDir "codex-zh-stderr.log"

function Log {
  param([string]$Message)
  $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message
  Write-Host $line
  try { Add-Content -LiteralPath $log -Value $line -Encoding UTF8 } catch {}
  try { Add-Content -LiteralPath $logCopy -Value $line -Encoding UTF8 } catch {}
}

function Log-FileTail {
  param([string]$Path, [string]$Name)
  if (-not (Test-Path -LiteralPath $Path)) {
    Log "$Name not found: $Path"
    return
  }
  $item = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
  if ($item) { Log "$Name size: $($item.Length)" }
  try {
    Get-Content -LiteralPath $Path -Tail 80 -ErrorAction Stop | ForEach-Object {
      Log "${Name}> $_"
    }
  } catch {
    Log "Failed to read ${Name}: $($_.Exception.Message)"
  }
}

function Log-PathStatus {
  param([string]$Label, [string]$Path)
  if (Test-Path -LiteralPath $Path) {
    $item = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    if ($item) {
      Log "$Label exists: $Path size=$($item.Length)"
    } else {
      Log "$Label exists: $Path"
    }
  } else {
    Log "$Label missing: $Path"
  }
}

New-Item -ItemType Directory -Force -Path $targetLogDir -ErrorAction SilentlyContinue | Out-Null
Remove-Item -LiteralPath $log, $logCopy -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $stdoutLog, $stderrLog, $stdoutLogCopy, $stderrLogCopy -Force -ErrorAction SilentlyContinue
Log "ChatGPT / Codex Chinese UI debug launcher"
Log "Product: $productName"
Log "User: $env:USERNAME"
Log "Computer: $env:COMPUTERNAME"
Log "PowerShell: $($PSVersionTable.PSVersion)"
Log "OS: $([Environment]::OSVersion.VersionString)"
Log "Target root: $targetRoot"
Log "Exe: $exe"
Log "User data: $targetData"

if (-not (Test-Path -LiteralPath $exe)) {
  Log "ERROR: Desktop app executable not found. Re-run install.bat."
  Read-Host "Press Enter to close"
  exit 1
}

$asar = Join-Path $targetApp "resources\app.asar"
Log-PathStatus "app.asar" $asar
Log-PathStatus "resource codex.exe" (Join-Path $targetApp "resources\codex.exe")
Log-PathStatus "bundled node.exe" (Join-Path $targetApp "resources\cua_node\bin\node.exe")
Log-PathStatus "target data dir" $targetData
Log-PathStatus "install metadata" $installInfoPath

Log "Stopping existing patched processes..."
foreach ($processName in @("ChatGPT", "Codex")) {
  Get-Process -Name $processName -ErrorAction SilentlyContinue | ForEach-Object {
    $processPath = $null
    try { $processPath = $_.Path } catch {}
    if ($processPath -and $processPath.StartsWith($targetApp, [System.StringComparison]::OrdinalIgnoreCase)) {
      Log "Stop PID $($_.Id) $processPath"
      Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
    } else {
      Log "Skip official/non-patched PID $($_.Id) $processPath"
    }
  }
}
Start-Sleep -Seconds 1

$env:CODEX_HOME = Join-Path $env:USERPROFILE ".codex"
$env:CODEX_ELECTRON_USER_DATA_PATH = $targetData
$env:ELECTRON_LOCALE_OVERRIDE = "zh-CN"
$env:ELECTRON_ENABLE_LOGGING = "1"
$env:ELECTRON_ENABLE_STACK_DUMPING = "1"

Log "Launching $exeName directly..."
try {
  $arguments = @("--user-data-dir=$targetData", "--lang=zh-CN")
  Log "Command: $exe $($arguments -join ' ')"
  $process = Start-Process -FilePath $exe -ArgumentList $arguments -WorkingDirectory $targetApp -RedirectStandardOutput $stdoutLog -RedirectStandardError $stderrLog -PassThru
  Start-Sleep -Seconds 5
  $process.Refresh()
  if (-not $process.HasExited) {
    Log "$productName is still running after 5 seconds. PID: $($process.Id)"
  } else {
    Log "$productName exited quickly. ExitCode: $($process.ExitCode)"
  }
} catch {
  Log "ERROR launching ${productName}: $($_.Exception.Message)"
}

Log-FileTail $stdoutLog "STDOUT"
Log-FileTail $stderrLog "STDERR"
try { if (Test-Path -LiteralPath $stdoutLog) { Copy-Item -LiteralPath $stdoutLog -Destination $stdoutLogCopy -Force } } catch {}
try { if (Test-Path -LiteralPath $stderrLog) { Copy-Item -LiteralPath $stderrLog -Destination $stderrLogCopy -Force } } catch {}

Log "Related processes after launch:"
foreach ($processName in @("ChatGPT", "Codex")) {
  Get-Process -Name $processName -ErrorAction SilentlyContinue | ForEach-Object {
    $processPath = $null
    try { $processPath = $_.Path } catch {}
    Log "PROCESS PID=$($_.Id) Name=$($_.ProcessName) Path=$processPath"
  }
}

Log "Recent files under user data:"
try {
  if (Test-Path -LiteralPath $targetData) {
    Get-ChildItem -LiteralPath $targetData -Recurse -File -ErrorAction SilentlyContinue |
      Sort-Object LastWriteTime -Descending |
      Select-Object -First 20 |
      ForEach-Object { Log ("DATA {0} size={1} {2}" -f $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss"), $_.Length, $_.FullName) }
  }
} catch {
  Log "Failed to list user data: $($_.Exception.Message)"
}

Log "Recent Windows application errors:"
$start = (Get-Date).AddMinutes(-10)
try {
  Get-WinEvent -FilterHashtable @{LogName="Application"; StartTime=$start} -ErrorAction SilentlyContinue |
    Where-Object { $_.Message -match "ChatGPT|Codex|Electron|app\.asar|OpenAI" -or $_.ProviderName -match "Application Error|Windows Error Reporting" } |
    Select-Object -First 12 |
    ForEach-Object {
      $eventMessage = $_.Message -replace "\s+", " "
      Log ("EVENT {0} {1} {2}" -f $_.TimeCreated, $_.ProviderName, $eventMessage.Substring(0, [Math]::Min(500, $eventMessage.Length)))
    }
} catch {
  Log "Failed to read Event Log: $($_.Exception.Message)"
}

Log "Done. Send this log file: $log"
Log "Backup log folder: $targetLogDir"
Read-Host "Press Enter to close"
