@echo off
setlocal
set "BOOTDIR=%TEMP%"
if not defined BOOTDIR set "BOOTDIR=%LOCALAPPDATA%\OpenAI\CodexZhInstaller"
if not exist "%BOOTDIR%\" (
  set "BOOTDIR=%LOCALAPPDATA%\OpenAI\CodexZhInstaller"
  if not exist "%LOCALAPPDATA%\OpenAI\CodexZhInstaller\" mkdir "%LOCALAPPDATA%\OpenAI\CodexZhInstaller" >nul 2>&1
)
if not exist "%BOOTDIR%\" set "BOOTDIR=%~dp0"
set "BOOTLOG=%BOOTDIR%\codex-zh-debug-bootstrap.log"
echo [%DATE% %TIME%] debug-launch.bat started>"%BOOTLOG%"
echo Folder: %~dp0>>"%BOOTLOG%"
where powershell.exe >>"%BOOTLOG%" 2>&1
if errorlevel 1 (
  echo powershell.exe not found>>"%BOOTLOG%"
  echo PowerShell not found. Log: "%BOOTLOG%"
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0debug-launch.ps1"
set "RC=0"
if errorlevel 1 set "RC=1"
echo [%DATE% %TIME%] debug-launch.bat finished, exit code %RC%>>"%BOOTLOG%"
if not "%RC%"=="0" (
  echo Debug launcher failed. Bootstrap log: "%BOOTLOG%"
  pause
)
exit /b %RC%
