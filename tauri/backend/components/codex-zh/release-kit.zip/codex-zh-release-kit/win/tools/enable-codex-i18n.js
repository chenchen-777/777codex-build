#!/usr/bin/env node
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

function log(message) {
  console.log(`[codex-i18n] ${message}`);
}

function die(message) {
  console.error(`[codex-i18n] ERROR: ${message}`);
  process.exit(1);
}

function sha256(buffer) {
  return crypto.createHash("sha256").update(buffer).digest("hex");
}

function findAll(buffer, needle) {
  const offsets = [];
  let cursor = 0;
  while (cursor <= buffer.length - needle.length) {
    const offset = buffer.indexOf(needle, cursor);
    if (offset < 0) break;
    offsets.push(offset);
    cursor = offset + needle.length;
  }
  return offsets;
}

function readAsar(asarPath) {
  const buffer = fs.readFileSync(asarPath);
  const jsonLength = buffer.readUInt32LE(12);
  const dataStart = 8 + buffer.readUInt32LE(4);
  const headerStart = 16;
  const headerJson = buffer.subarray(headerStart, headerStart + jsonLength).toString("utf8");
  const header = JSON.parse(headerJson);
  return { buffer, header, headerStart, headerJson, dataStart };
}

function walkFiles(node, prefix, visit) {
  if (!node.files) return;
  for (const [name, child] of Object.entries(node.files)) {
    const current = prefix ? `${prefix}/${name}` : name;
    if (child.files) walkFiles(child, current, visit);
    else visit(current, child);
  }
}

function getNode(header, filePath) {
  let node = { files: header.files };
  for (const part of filePath.split("/")) {
    node = node.files && node.files[part];
    if (!node) return null;
  }
  return node;
}

function readFile(archive, filePath) {
  const node = getNode(archive.header, filePath);
  if (!node || node.files) return null;
  const start = archive.dataStart + Number(node.offset || 0);
  return archive.buffer.subarray(start, start + Number(node.size || 0));
}

function updateIntegrity(node, buffer) {
  if (!node.integrity) return;
  const blockSize = node.integrity.blockSize || 4194304;
  const blocks = [];
  for (let i = 0; i < buffer.length; i += blockSize) {
    blocks.push(sha256(buffer.subarray(i, Math.min(i + blockSize, buffer.length))));
  }
  node.integrity = {
    algorithm: "SHA256",
    hash: sha256(buffer),
    blockSize,
    blocks,
  };
}

function replaceHeaderHashesInPlace(archive, updatedNodes) {
  let headerJson = archive.headerJson;
  for (const { before, after } of updatedNodes) {
    if (!before.integrity || !after.integrity) continue;
    const pairs = [[before.integrity.hash, after.integrity.hash]];
    const beforeBlocks = before.integrity.blocks || [];
    const afterBlocks = after.integrity.blocks || [];
    if (beforeBlocks.length !== afterBlocks.length) {
      die("Cannot update ASAR integrity in place because block count changed.");
    }
    for (let i = 0; i < beforeBlocks.length; i += 1) {
      pairs.push([beforeBlocks[i], afterBlocks[i]]);
    }
    const seenOldHashes = new Set();
    for (const [oldHash, newHash] of pairs) {
      if (!oldHash || !newHash || oldHash.length !== newHash.length) {
        die("Cannot update ASAR integrity in place because hash length changed.");
      }
      if (seenOldHashes.has(oldHash)) continue;
      seenOldHashes.add(oldHash);
      const countBefore = headerJson.split(oldHash).length - 1;
      if (countBefore < 1) {
        die(`Cannot find old integrity hash in ASAR header: ${oldHash}`);
      }
      headerJson = headerJson.split(oldHash).join(newHash);
    }
  }
  if (Buffer.byteLength(headerJson, "utf8") !== Buffer.byteLength(archive.headerJson, "utf8")) {
    die("Cannot update ASAR header in place because header length changed.");
  }
  return Buffer.from(headerJson, "utf8");
}

function writeAsarInPlace(asarPath, archive, replacements) {
  const output = Buffer.from(archive.buffer);
  const updatedNodes = [];

  for (const [filePath, next] of replacements) {
    const node = getNode(archive.header, filePath);
    if (!node || node.files) die(`ASAR node not found for replacement: ${filePath}`);
    const original = readFile(archive, filePath);
    if (original.length !== next.length) {
      die(`Replacement length changed for ${filePath}. Refusing to rewrite ASAR container.`);
    }

    const start = archive.dataStart + Number(node.offset || 0);
    next.copy(output, start);

    const before = JSON.parse(JSON.stringify(node));
    updateIntegrity(node, next);
    const after = JSON.parse(JSON.stringify(node));
    updatedNodes.push({ before, after });
  }

  const patchedHeader = replaceHeaderHashesInPlace(archive, updatedNodes);
  patchedHeader.copy(output, archive.headerStart);
  fs.writeFileSync(asarPath, output);
  return sha256(patchedHeader);
}

function patchExeIntegrityMarker(exePath, oldHash, newHash) {
  if (!exePath || !fs.existsSync(exePath)) {
    log("Windows executable was not supplied. Skipping embedded ASAR hash update.");
    return 0;
  }

  const exe = fs.readFileSync(exePath);
  const encodings = [
    { name: "ASCII", oldValue: Buffer.from(oldHash, "ascii"), newValue: Buffer.from(newHash, "ascii") },
    { name: "UTF-16LE", oldValue: Buffer.from(oldHash, "utf16le"), newValue: Buffer.from(newHash, "utf16le") },
  ];
  let replacements = 0;

  for (const encoding of encodings) {
    const offsets = findAll(exe, encoding.oldValue);
    for (const offset of offsets) {
      encoding.newValue.copy(exe, offset);
      replacements += 1;
    }
    if (offsets.length > 0) {
      log(`updated ${offsets.length} ${encoding.name} ASAR integrity marker(s) in ${path.basename(exePath)}`);
    }
  }

  if (replacements === 0) {
    log(`${path.basename(exePath)} has no embedded app.asar header marker. This build does not need an exe marker update.`);
    return 0;
  }

  const backupPath = `${exePath}.bak-before-i18n`;
  if (!fs.existsSync(backupPath)) {
    fs.copyFileSync(exePath, backupPath);
    log(`exe backup: ${backupPath}`);
  }
  fs.writeFileSync(exePath, exe);
  return replacements;
}

function patchI18nSource(source) {
  let next = source;
  const replacements = [
    [/get\(`enable_i18n`,!1\)/g, "get(`enable_i18n`,!0)"],
    [/get\("enable_i18n",!1\)/g, 'get("enable_i18n",!0)'],
    [/get\('enable_i18n',!1\)/g, "get('enable_i18n',!0)"],
    [/get\(`enable_i18n`,false\)/g, "get(`enable_i18n`,true )"],
    [/get\("enable_i18n",false\)/g, 'get("enable_i18n",true )'],
    [/get\('enable_i18n',false\)/g, "get('enable_i18n',true )"],
  ];

  let count = 0;
  for (const [pattern, replacement] of replacements) {
    next = next.replace(pattern, () => {
      count += 1;
      return replacement;
    });
  }

  return { next, count };
}

async function main() {
  const asarPath = process.env.CODEX_ASAR || process.argv[2];
  const exeFlagIndex = process.argv.indexOf("--exe");
  const exePath = exeFlagIndex >= 0 ? process.argv[exeFlagIndex + 1] : null;
  if (!asarPath) die("Usage: node tools/enable-codex-i18n.js <path-to-app.asar>");
  if (!fs.existsSync(asarPath)) die(`app.asar not found: ${asarPath}`);

  const archive = readAsar(asarPath);
  const originalHeaderHash = sha256(Buffer.from(archive.headerJson, "utf8"));
  const replacements = new Map();
  let total = 0;
  let alreadyEnabled = false;

  walkFiles(archive.header, "", (filePath, node) => {
    if (!filePath.endsWith(".js")) return;
    const original = readFile(archive, filePath);
    const source = original.toString("utf8");
    if (!source.includes("enable_i18n")) return;
    if (
      source.includes("get(`enable_i18n`,!0)") ||
      source.includes('get("enable_i18n",!0)') ||
      source.includes("get('enable_i18n',!0)") ||
      source.includes("get(`enable_i18n`,true)") ||
      source.includes('get("enable_i18n",true)') ||
      source.includes("get('enable_i18n',true)") ||
      source.includes("get(`enable_i18n`,true )") ||
      source.includes('get("enable_i18n",true )') ||
      source.includes("get('enable_i18n',true )")
    ) {
      alreadyEnabled = true;
    }

    const { next, count } = patchI18nSource(source);
    if (count > 0) {
      if (Buffer.byteLength(next, "utf8") !== original.length) {
        die(`Patched source length changed for ${filePath}. This build needs a new in-place pattern.`);
      }
      total += count;
      replacements.set(filePath, Buffer.from(next, "utf8"));
      log(`patched ${filePath}: ${count}`);
    } else {
      log(`found enable_i18n but no false default pattern in ${filePath}`);
    }
  });

  if (total === 0) {
    if (alreadyEnabled) {
      log("enable_i18n already defaults to true.");
      return;
    }
    die("No enable_i18n false default was patched. This Codex version may use a different pattern.");
  }

  const backupPath = `${asarPath}.bak-before-i18n`;
  if (!fs.existsSync(backupPath)) {
    fs.copyFileSync(asarPath, backupPath);
    log(`backup: ${backupPath}`);
  }

  const patchedHeaderHash = writeAsarInPlace(asarPath, archive, replacements);
  patchExeIntegrityMarker(exePath, originalHeaderHash, patchedHeaderHash);
  log(`done, patched replacements: ${total}`);
}

main().catch((error) => die(error.stack || error.message));
