@echo off
setlocal
set "BOOTDIR=%TEMP%"
if not defined BOOTDIR set "BOOTDIR=%LOCALAPPDATA%\OpenAI\CodexZhInstaller"
if not exist "%BOOTDIR%\" (
  set "BOOTDIR=%LOCALAPPDATA%\OpenAI\CodexZhInstaller"
  if not exist "%LOCALAPPDATA%\OpenAI\CodexZhInstaller\" mkdir "%LOCALAPPDATA%\OpenAI\CodexZhInstaller" >nul 2>&1
)
if not exist "%BOOTDIR%\" set "BOOTDIR=%~dp0"
set "BOOTLOG=%BOOTDIR%\codex-zh-install-bootstrap.log"
echo [%DATE% %TIME%] install.bat started>"%BOOTLOG%"
echo Folder: %~dp0>>"%BOOTLOG%"
echo This is only the bootstrap log. The PowerShell installer writes the real log to the actual Windows Desktop folder.>>"%BOOTLOG%"
echo If there is no "finished" line, the installer window is still open, waiting for input, or was closed before completion.>>"%BOOTLOG%"
pushd "%~dp0"
where powershell.exe >>"%BOOTLOG%" 2>&1
if errorlevel 1 (
  echo powershell.exe not found>>"%BOOTLOG%"
  echo PowerShell not found. Log: "%BOOTLOG%"
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%CD%\install-user-copy.ps1"
set "RC=0"
if errorlevel 1 set "RC=1"
echo [%DATE% %TIME%] install.bat finished, exit code %RC%>>"%BOOTLOG%"
popd
if not "%RC%"=="0" (
  echo Install failed. Bootstrap log: "%BOOTLOG%"
  pause
)
exit /b %RC%
