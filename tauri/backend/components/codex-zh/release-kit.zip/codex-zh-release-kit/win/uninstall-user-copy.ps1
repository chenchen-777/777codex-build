Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-LocalAppData {
  $value = [Environment]::GetFolderPath("LocalApplicationData")
  if (-not $value) { $value = $env:LOCALAPPDATA }
  if (-not $value) { $value = Join-Path $env:USERPROFILE "AppData\Local" }
  return $value
}

$localAppData = Get-LocalAppData
$installPathFile = Join-Path $localAppData "OpenAI\CodexZhInstaller\install-path.txt"
$defaultRoot = Join-Path $localAppData "OpenAI\CodexZh"
if (Test-Path -LiteralPath $installPathFile) {
  $configuredRoot = (Get-Content -LiteralPath $installPathFile -Raw -ErrorAction SilentlyContinue).Trim()
  $targetRoot = if ($configuredRoot) { $configuredRoot } else { $defaultRoot }
} else {
  $targetRoot = $defaultRoot
}

$targetApp = Join-Path $targetRoot "app"
$desktop = [Environment]::GetFolderPath("Desktop")
if (-not $desktop) { $desktop = $env:USERPROFILE }

foreach ($processName in @("ChatGPT", "Codex")) {
  Get-Process -Name $processName -ErrorAction SilentlyContinue | ForEach-Object {
    $processPath = $null
    try { $processPath = $_.Path } catch {}
    if ($processPath -and $processPath.StartsWith($targetApp, [System.StringComparison]::OrdinalIgnoreCase)) {
      Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
    }
  }
}

foreach ($desktopFile in @(
  "Codex Zh.lnk",
  "ChatGPT Zh.lnk",
  "Open Codex Zh.bat",
  "Open ChatGPT Zh.bat",
  "Debug Codex Zh.bat",
  "Debug ChatGPT Zh.bat"
)) {
  Remove-Item -LiteralPath (Join-Path $desktop $desktopFile) -Force -ErrorAction SilentlyContinue
}

Remove-Item -LiteralPath $targetRoot -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $installPathFile -Force -ErrorAction SilentlyContinue

Write-Host "Removed the ChatGPT / Codex Chinese copy from: $targetRoot"
Write-Host "The official Microsoft Store app was not changed."
Read-Host "Press Enter to close"
