ChatGPT / Codex Chinese UI patch kit

Version: v2026.07.14.0850

Please read instructions.pdf first.

Folder layout:

- win
  For Windows users.
  Run install.bat.

- mac
  For macOS users.
  Right-click install-mac.command and choose Open.

Compatibility:

- New unified ChatGPT desktop app with Chat, Work, and Codex.
- Legacy standalone Codex desktop app.
- Windows Microsoft Store/MSIX package family OpenAI.Codex.
- macOS /Applications/ChatGPT.app and legacy /Applications/Codex.app.

Important:

- Install and open the official desktop app once before using this kit.
- This kit creates a separate Chinese copy. It does not overwrite the official app.
- In the new app, open ChatGPT Zh and choose Codex from the top-left mode menu.
- Success message shows author 大瑜 and WeChat helloaigc2023.
