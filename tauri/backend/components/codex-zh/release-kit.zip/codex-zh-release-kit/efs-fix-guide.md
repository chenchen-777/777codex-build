# Windows 错误 6000：无法加密指定的文件

如果安装时出现下面的提示，说明目标文件夹启用了 Windows EFS 文件加密，ChatGPT / Codex 的核心文件无法复制：

```text
错误 6000 (0x00001770)
无法加密指定的文件
The specified file could not be encrypted
```

这不是汉化代码损坏，也不是用户点错了。

## 最简单的处理方法

1. 关闭安装窗口。
2. 重新双击 `win\install.bat`，安装位置输入 `3`。
3. 输入一个没有开启加密的新目录，例如：

```text
C:\CodexZh
```

如果 C 盘没有权限，就输入：

```text
D:\CodexZh
```

4. 安装完成后，从桌面的 `ChatGPT Zh` 打开，再在左上角选择 `Codex`。

## 仍想使用默认目录

1. 打开下面的目录：

```text
C:\Users\你的用户名\AppData\Local\OpenAI
```

2. 如果里面已有 `CodexZh`，先删除这个失败残留。
3. 右键 `OpenAI` 文件夹本身，选择 `属性` -> `高级`，取消勾选 `加密内容以便保护数据`。
4. 系统询问应用范围时，选择 `应用到此文件夹、子文件夹和文件`，然后重新运行 `install.bat` 并选择 `1`。

## 发送日志

如果仍然失败，请发送桌面的这两个文件：

```text
codex-zh-install.log
%TEMP%\codex-zh-install-bootstrap.log
```

如果 `%TEMP%` 中没有启动日志，再查看 `%LOCALAPPDATA%\OpenAI\CodexZhInstaller`。
