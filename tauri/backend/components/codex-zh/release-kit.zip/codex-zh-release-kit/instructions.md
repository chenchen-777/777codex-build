# ChatGPT / Codex 中文界面补丁包使用说明

版本：v2026.07.14.0850

## 先看这一条

2026 年 7 月起，Codex 已经进入新的 ChatGPT 桌面应用。安装汉化包后，你打开的是 `ChatGPT Zh`，然后从左上角的模式菜单选择 `Codex`。

本包也兼容旧版独立 Codex Desktop。

## 汉化原理

ChatGPT / Codex 桌面应用里已经包含中文界面资源，但部分电脑拿不到开启中文界面的远程配置，所以一直显示英文。

本补丁会复制一份官方应用，在副本里打开中文界面开关。官方应用不会被覆盖，官方目录也不会被修改。

## Windows 安装

1. 安装官方 ChatGPT 桌面应用，并确认官方应用能够打开。
2. 关闭 ChatGPT / Codex。
3. 解压补丁包，打开 `win` 文件夹。
4. 双击 `install.bat`。
5. 安装位置直接按回车，使用默认安装。
6. 等到出现“汉化成功”。
7. 打开桌面的 `ChatGPT Zh`。如果桌面显示 `Codex Zh`，说明电脑安装的是旧版 Codex，也可以正常使用。
8. 新版应用打开后，从左上角模式菜单选择 `Codex`。

安装位置说明：

- `1` 或直接回车：首次安装使用默认位置；如果以前安装在 D 盘，会自动显示并沿用原来的 D 盘目录。
- `2`：弹窗选择文件夹，例如选择 D 盘。
- `3`：手动输入完整安装路径，例如 `F:\AI工具\中文Codex`；程序会完全按照填写的目录安装，不会额外增加文件夹。

出现错误 6000 或“无法加密指定的文件”时，请查看 `efs-fix-guide.pdf`。

## macOS 安装

1. 安装官方 ChatGPT 桌面应用，并确认官方应用能够打开。
2. 关闭 ChatGPT / Codex。
3. 解压补丁包，打开 `mac` 文件夹。
4. 右键 `install-mac.command`，选择“打开”。不要直接双击。
5. 如果系统仍然拦截，进入“系统设置” -> “隐私与安全性”，点击“仍要打开”。
6. 等到出现“汉化成功”。
7. 打开 `~/Applications/ChatGPT Zh.app`。
8. 从左上角模式菜单选择 `Codex`。

旧版 Mac 会生成 `~/Applications/Codex Zh.app`。

## 更新与卸载

官方 ChatGPT / Codex 更新后，重新运行一次对应系统的安装脚本。

- Windows 卸载：双击 `win\uninstall.bat`。
- macOS 卸载：右键 `mac\uninstall-mac.command`，选择“打开”。

卸载只删除中文副本，不会删除官方应用。

## 排查日志

Windows 安装失败时，发送桌面的 `codex-zh-install.log`。

安装成功但打不开时，运行桌面的 Debug 脚本，再发送 `codex-zh-debug.log`。

## 作者

大瑜，微信号 helloaigc2023。欢迎关注，分享更多 AI 资讯和信息。
